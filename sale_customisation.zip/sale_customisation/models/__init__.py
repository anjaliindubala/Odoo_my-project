from .import sale_order
from .import res_config
from .import stock_move