from odoo.tools.float_utils import float_compare
from itertools import groupby
from odoo import models


class StockMove(models.Model):
    _inherit = 'stock.move'

    def _assign_picking(self):
        Picking = self.env['stock.picking']

        auto_flow_enabled = any(
            move.sale_line_id.order_id.auto_workflow
            for move in self if move.sale_line_id.order_id
        )

        if auto_flow_enabled:
            pickings_by_product = {}

            for move in self:
                product_id = move.product_id.id
                picking = pickings_by_product.get(product_id)

                if picking:
                    existing_move = picking.move_ids_without_package.filtered(lambda m: m.product_id.id == product_id)
                    if existing_move:
                        existing_move.product_uom_qty += move.product_uom_qty
                    else:
                        new_move = move.copy({'picking_id': picking.id})
                        pickings_by_product[product_id].move_ids_without_package += new_move

                else:
                    picking = Picking.create(move._get_new_picking_values())
                    new_move = move.copy({'picking_id': picking.id})
                    pickings_by_product[product_id] = picking
                    pickings_by_product[product_id].move_ids_without_package += new_move

                    picking.action_confirm()
                    picking.action_assign()
                    if picking.state=='assigned':
                        picking.button_validate()



        else:
            grouped_moves = groupby(self, key=lambda m: m._key_assign_picking())
            for group, moves in grouped_moves:
                moves = self.env['stock.move'].concat(*moves)
                new_picking = False
                picking = moves[0]._search_picking_for_assignation()

                if picking:
                    vals = {}
                    if any(picking.partner_id.id != m.partner_id.id for m in moves):
                        vals['partner_id'] = False
                    if any(picking.origin != m.origin for m in moves):
                        vals['origin'] = False
                    if vals:
                        picking.write(vals)
                else:
                    moves = moves.filtered(
                        lambda m: float_compare(m.product_uom_qty, 0.0, precision_rounding=m.product_uom.rounding) >= 0)
                    if not moves:
                        continue
                    new_picking = True
                    picking = Picking.create(moves._get_new_picking_values())

                moves.write({'picking_id': picking.id})
                moves._assign_picking_post_process(new=new_picking)

        return True
