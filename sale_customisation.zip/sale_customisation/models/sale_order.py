from odoo import models, fields,api,_
from odoo.exceptions import UserError

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    manager_reference = fields.Text(string="Manager Reference")
    is_sale_admin = fields.Boolean(compute="_compute_sale_admin",store=True)
    auto_workflow = fields.Boolean(string="Auto Workflow")

    @api.depends('name')
    def _compute_sale_admin(self):
        for record in self:
            record.is_sale_admin = self.env.user.has_group('sale_customisation.group_sale_admin')

    def action_confirm(self):
        sale_order_limit = float(self.env['ir.config_parameter'].sudo().get_param('sale.sale_order_limit', 0.0))
        is_sale_admin = self.env.user.has_group('sale_customisation.group_sale_admin')

        for order in self:
            if order.amount_total > sale_order_limit and not is_sale_admin:
                raise UserError(
                    _("You cannot confirm this sale order because the order amount exceeds the Sale Order Limit. Please contact a Sale Admin."))

        res = super(SaleOrder, self).action_confirm()



class StockPicking(models.Model):
    _inherit = 'stock.picking'

    def button_validate(self):
        res = super(StockPicking, self).button_validate()

        for picking in self:
            sale_order = self.env['sale.order'].search([('name', '=', picking.origin)], limit=1)

            if sale_order and sale_order.auto_workflow:
                    invoice = sale_order._create_invoices()

                    if invoice:
                        invoice.action_post()
                        self._register_payment(invoice)
                    else:
                        raise UserError(_("Failed to create an invoice for the Sale Order."))

        return res

    def _register_payment(self, invoice):

        # payment_method = self.env.ref('account.account_payment_method_manual_in')
        payment_register = self.env['account.payment.register'].with_context(active_model='account.move', active_ids=invoice.ids).create({
            'payment_date': fields.Date.today(),
            'journal_id': self.env['account.journal'].search([('type', '=', 'bank')], limit=1).id,
            'amount': invoice.amount_residual,
        })
        payment_register._create_payments()

