# -*- coding: utf-8 -*-
{
    'name': 'Sale customisation',
    'version': '1.0.1',
    'author': 'Anjali',
    'summary': """ Sale Cutomisation""",
    'description': """ Sale Cutomisation""",
    'depends': [
        'base',
        'sale',
        'sale_management',
        'stock'
    ],
    'data': [
        'security/security.xml',
        'views/sale_order.xml',
        'views/res_config_settings.xml',

    ],
    'installable': True,
    'application': True,
}
